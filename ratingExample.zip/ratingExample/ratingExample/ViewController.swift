//
//  ViewController.swift
//  ratingExample
//
//  Created by Synergy on 14/03/18.
//  Copyright © 2018 Synergy.com.nl. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var mealNameLabel: UILabel!

    @IBOutlet weak var photoImageView: UIImageView!

    @IBAction func setDefaultLabelText(_ sender: AnyObject) {
        print("bubu")
        mealNameLabel.text = nameTextField.text
    }
    
    @IBOutlet weak var nameTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        nameTextField.delegate = self
        
        let tapPhotoImageView = UITapGestureRecognizer(target: self, action: #selector(self.handleTapPhotoView(sender:)))
        photoImageView.isUserInteractionEnabled = true
        photoImageView.addGestureRecognizer(tapPhotoImageView)
        
    }

   @objc func handleTapPhotoView(sender:UITapGestureRecognizer? = nil) {
        print("handleTapPhotoView")
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = .photoLibrary
        self.present(imagePickerController, animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            print("bubu")
            photoImageView.image = image
            dismiss(animated: true, completion: nil)
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

}

