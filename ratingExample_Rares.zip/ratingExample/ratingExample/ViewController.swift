//
//  ViewController.swift
//  ratingExample
//
//  Created by Romania on 14.03.2018.
//  Copyright © 2018 DMT Marine Equipment. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate{
   
    @IBOutlet weak var mealNameLabel: UILabel!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var photoImageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        nameTextField.delegate = self
        let tapImagePicker = UITapGestureRecognizer(target: self, action: #selector(ViewController.handleTapImage(sender:)))
        let tap = UITapGestureRecognizer(target: self, action: #selector(ViewController.handleTap(sender:)))
        view.addGestureRecognizer(tap)
        photoImageView.addGestureRecognizer(tapImagePicker)
        photoImageView.isUserInteractionEnabled = true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    @objc func handleTap(sender: UITapGestureRecognizer? = nil)
    {
        print("sunt in handle tap")
        if nameTextField.isFirstResponder == true
        {
            nameTextField.resignFirstResponder()
        }
    }
    @objc func handleTapImage(sender: UIImagePickerController? = nil)
    {
        print("sunt in handleTapImage")
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        
        imagePicker.sourceType = .photoLibrary
        self.present(imagePicker, animated: true, completion: nil)
        
    }
    @IBAction func setDefaultLabelText(_ sender: Any) {
    if nameTextField.text?.isEmpty == false
    {
        mealNameLabel.text = nameTextField.text
        
        }
    else {
        print("Nu a fost introdus nimic")
        }
    
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
    }
}

